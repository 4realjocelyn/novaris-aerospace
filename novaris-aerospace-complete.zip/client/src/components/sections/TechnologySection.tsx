import React from 'react';

/**
 * Technology Section Component
 * Design: Professional specs and feature showcase
 */
export default function TechnologySection() {
  const features = [
    {
      title: 'Advanced Propulsion',
      description: 'Next-generation rocket engines with optimized thrust-to-weight ratios and reusability.',
      icon: '🚀',
    },
    {
      title: 'Precision Guidance',
      description: 'AI-powered navigation systems for autonomous flight control and trajectory optimization.',
      icon: '🎯',
    },
    {
      title: 'Real-time Telemetry',
      description: 'Live mission data streaming with millisecond precision and redundant communication systems.',
      icon: '📡',
    },
    {
      title: 'Payload Integration',
      description: 'Modular payload bay supporting diverse mission requirements and scientific instruments.',
      icon: '📦',
    },
  ];

  const specs = [
    { label: 'Max Altitude', value: '500 KM' },
    { label: 'Thrust', value: '1,500 kN' },
    { label: 'Payload Capacity', value: '5,000 KG' },
    { label: 'Launch Frequency', value: '12/Year' },
  ];

  return (
    <section id="technology" className="relative py-32 px-4 bg-slate-900">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="mb-20">
          <span className="text-blue-400 text-sm font-semibold uppercase tracking-widest">Technology</span>
          <h2 className="cinematic-heading text-4xl md:text-5xl mt-4 mb-6">
            Engineering
            <span className="block text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-cyan-400">
              Excellence
            </span>
          </h2>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-20">
          {features.map((feature, index) => (
            <div
              key={index}
              className={`cinematic-card hover-glow ${index === 0 ? 'stagger-1' : index === 1 ? 'stagger-2' : index === 2 ? 'stagger-3' : 'stagger-4'} fade-in-up`}
            >
              <div className="text-4xl mb-4">{feature.icon}</div>
              <h3 className="text-xl font-bold text-white mb-3">{feature.title}</h3>
              <p className="text-slate-300 leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>

        {/* Specifications */}
        <div className="bg-gradient-to-r from-blue-900 to-slate-900 rounded-lg p-8 border border-blue-800">
          <h3 className="text-2xl font-bold text-white mb-8">NOVARIS-01 Specifications</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {specs.map((spec, index) => (
              <div key={index} className="text-center">
                <div className="stat-label mb-2">{spec.label}</div>
                <div className="stat-value">{spec.value}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
