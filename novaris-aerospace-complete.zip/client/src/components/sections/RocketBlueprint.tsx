import React, { useState } from 'react';

/**
 * Rocket Blueprint Component
 * Design: Military-grade tactical dashboard with interactive rocket blueprint
 * Features: Interactive component selection, technical specifications, 3D-like rendering
 */
export default function RocketBlueprint() {
  const [selectedComponent, setSelectedComponent] = useState<string | null>(null);

  const components = [
    {
      id: 'payload',
      name: 'PAYLOAD MODULE',
      position: 'top-8',
      height: 'h-12',
      description: 'Primary mission payload and instrumentation',
      specs: ['Mass: 500 kg', 'Power: 2.5 kW', 'Status: NOMINAL'],
    },
    {
      id: 'guidance',
      name: 'GUIDANCE SYSTEM',
      position: 'top-20',
      height: 'h-8',
      description: 'Inertial navigation and flight control',
      specs: ['Accuracy: ±0.1°', 'Update Rate: 1000 Hz', 'Status: NOMINAL'],
    },
    {
      id: 'avionics',
      name: 'AVIONICS BAY',
      position: 'top-28',
      height: 'h-16',
      description: 'Flight computers and telemetry systems',
      specs: ['Processors: 4x', 'Memory: 32 GB', 'Status: NOMINAL'],
    },
    {
      id: 'fuel-tank',
      name: 'FUEL TANK',
      position: 'top-44',
      height: 'h-24',
      description: 'Liquid oxygen and RP-1 propellant',
      specs: ['Capacity: 50,000 L', 'Pressure: 45 bar', 'Level: 100%'],
    },
    {
      id: 'engines',
      name: 'MAIN ENGINES',
      position: 'bottom-8',
      height: 'h-12',
      description: 'Primary propulsion system',
      specs: ['Thrust: 500 kN', 'ISP: 310s', 'Status: READY'],
    },
  ];

  return (
    <section
      id="blueprint"
      className="relative bg-black border-b-4 border-green-400 py-16 px-4 overflow-hidden"
    >
      {/* Tactical Grid Background */}
      <div className="absolute inset-0 tactical-grid opacity-10 pointer-events-none"></div>

      <div className="relative z-10 max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="mb-8">
          <div className="tactical-label">VEHICLE DESIGN</div>
          <h2 className="tactical-heading text-3xl md:text-4xl mt-2">ROCKET BLUEPRINT</h2>
        </div>

        {/* Blueprint Display */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Rocket Schematic */}
          <div className="lg:col-span-2 tactical-card">
            <div className="tactical-label">NOVARIS-01 SCHEMATIC</div>
            <div className="mt-6 flex justify-center">
              <div className="relative w-32 h-96 border-2 border-green-400 bg-black bg-opacity-50">
                {/* Rocket body outline */}
                <svg className="absolute inset-0 w-full h-full" viewBox="0 0 100 400">
                  {/* Main body */}
                  <rect x="35" y="0" width="30" height="360" fill="none" stroke="#00ff00" strokeWidth="1" />

                  {/* Fins */}
                  <polygon points="35,340 20,380 35,360" fill="none" stroke="#00ff00" strokeWidth="1" />
                  <polygon points="65,340 80,380 65,360" fill="none" stroke="#00ff00" strokeWidth="1" />

                  {/* Nozzles */}
                  <rect x="30" y="360" width="15" height="30" fill="none" stroke="#ff6600" strokeWidth="1" />
                  <rect x="55" y="360" width="15" height="30" fill="none" stroke="#ff6600" strokeWidth="1" />
                </svg>

                {/* Interactive Components */}
                {components.map((component) => (
                  <button
                    key={component.id}
                    onClick={() => setSelectedComponent(component.id)}
                    className={`absolute left-0 right-0 mx-auto transition-all ${component.position} ${component.height} border-2 cursor-pointer ${
                      selectedComponent === component.id
                        ? 'border-yellow-400 bg-yellow-400 bg-opacity-20'
                        : 'border-green-400 hover:border-yellow-400 hover:bg-yellow-400 hover:bg-opacity-10'
                    }`}
                    title={component.name}
                  >
                    <div className="text-xs font-bold text-center truncate px-1">
                      {component.name.split(' ')[0]}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Component List */}
            <div className="mt-6 space-y-2">
              {components.map((component) => (
                <button
                  key={component.id}
                  onClick={() => setSelectedComponent(component.id)}
                  className={`w-full p-2 text-left text-xs border border-green-400 transition-all ${
                    selectedComponent === component.id
                      ? 'bg-green-400 bg-opacity-20 border-yellow-400'
                      : 'hover:border-yellow-400'
                  }`}
                >
                  <div className="flex justify-between items-center">
                    <span className="tactical-label">{component.name}</span>
                    <span className="text-green-400">✓</span>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Component Details */}
          <div className="tactical-card">
            <div className="tactical-label">COMPONENT DETAILS</div>
            <div className="mt-4">
              {selectedComponent ? (
                <div className="space-y-4">
                  {components.map((component) => {
                    if (component.id !== selectedComponent) return null;
                    return (
                      <div key={component.id}>
                        <div className="text-green-400 font-bold text-lg mb-2">{component.name}</div>
                        <div className="text-xs text-green-400 opacity-70 mb-4">{component.description}</div>
                        <div className="border-t border-green-400 pt-3 space-y-2">
                          {component.specs.map((spec, idx) => (
                            <div key={idx} className="flex justify-between text-xs">
                              <span className="tactical-label">{spec.split(':')[0]}</span>
                              <span className="text-green-400">{spec.split(':')[1]}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="text-green-400 text-xs opacity-60">
                  Select a component to view specifications
                </div>
              )}
            </div>

            {/* System Status */}
            <div className="mt-6 border-t border-green-400 pt-4">
              <div className="tactical-label mb-3">SYSTEM STATUS</div>
              <div className="space-y-2 text-xs">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                  <span>STRUCTURAL - NOMINAL</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                  <span>PROPULSION - READY</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                  <span>AVIONICS - NOMINAL</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                  <span>PAYLOAD - READY</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Technical Specifications */}
        <div className="mt-8 tactical-card">
          <div className="tactical-label">VEHICLE SPECIFICATIONS</div>
          <div className="mt-4 grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
            <div>
              <span className="tactical-label">HEIGHT</span>
              <div className="text-green-400 font-bold">70 M</div>
            </div>
            <div>
              <span className="tactical-label">DIAMETER</span>
              <div className="text-green-400 font-bold">3.7 M</div>
            </div>
            <div>
              <span className="tactical-label">MASS</span>
              <div className="text-green-400 font-bold">550 T</div>
            </div>
            <div>
              <span className="tactical-label">THRUST</span>
              <div className="text-green-400 font-bold">1,500 kN</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
