import React, { useState, useEffect } from 'react';

/**
 * Engineering Logs Component
 * Design: Military-grade tactical dashboard with live system logs
 * Features: Real-time event logging, status filtering, timestamp tracking
 */
export default function EngineeringLogs() {
  const [logs, setLogs] = useState<any[]>([]);
  const [filter, setFilter] = useState('all');

  const logTypes = [
    { id: 'all', label: 'ALL EVENTS', color: '#00ff00' },
    { id: 'nominal', label: 'NOMINAL', color: '#00ff00' },
    { id: 'warning', label: 'WARNINGS', color: '#ffff00' },
    { id: 'critical', label: 'CRITICAL', color: '#ff0000' },
  ];

  // Generate mock logs
  useEffect(() => {
    const mockLogs = [
      { id: 1, time: '14:32:45', type: 'nominal', message: 'SYSTEM INITIALIZATION COMPLETE' },
      { id: 2, time: '14:32:46', type: 'nominal', message: 'TELEMETRY LINK ESTABLISHED' },
      { id: 3, time: '14:32:47', type: 'nominal', message: 'GUIDANCE SYSTEM ONLINE' },
      { id: 4, time: '14:32:48', type: 'nominal', message: 'AVIONICS SELF-TEST PASSED' },
      { id: 5, time: '14:32:49', type: 'nominal', message: 'FUEL SYSTEM PRESSURIZED' },
      { id: 6, time: '14:32:50', type: 'nominal', message: 'ENGINES READY FOR IGNITION' },
      { id: 7, time: '14:32:51', type: 'warning', message: 'MINOR PRESSURE FLUCTUATION DETECTED' },
      { id: 8, time: '14:32:52', type: 'nominal', message: 'PRESSURE NORMALIZED' },
      { id: 9, time: '14:32:53', type: 'nominal', message: 'FINAL SYSTEM CHECK COMPLETE' },
      { id: 10, time: '14:32:54', type: 'nominal', message: 'READY FOR LAUNCH SEQUENCE' },
    ];
    setLogs(mockLogs);
  }, []);

  const filteredLogs =
    filter === 'all' ? logs : logs.filter((log) => log.type === filter);

  const getLogColor = (type: string) => {
    switch (type) {
      case 'nominal':
        return 'text-green-400';
      case 'warning':
        return 'text-yellow-400';
      case 'critical':
        return 'text-red-400';
      default:
        return 'text-green-400';
    }
  };

  return (
    <section
      id="logs"
      className="relative bg-black border-b-4 border-green-400 py-16 px-4 overflow-hidden"
    >
      {/* Tactical Grid Background */}
      <div className="absolute inset-0 tactical-grid opacity-10 pointer-events-none"></div>

      <div className="relative z-10 max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="mb-8">
          <div className="tactical-label">MISSION LOG</div>
          <h2 className="tactical-heading text-3xl md:text-4xl mt-2">ENGINEERING LOGS</h2>
        </div>

        {/* Filter Controls */}
        <div className="mb-6 flex gap-2 flex-wrap">
          {logTypes.map((logType) => (
            <button
              key={logType.id}
              onClick={() => setFilter(logType.id)}
              className={`px-4 py-2 text-xs font-bold uppercase tracking-wider border transition-all ${
                filter === logType.id
                  ? 'border-green-400 bg-green-400 text-black'
                  : 'border-green-400 text-green-400 hover:bg-green-400 hover:text-black'
              }`}
            >
              {logType.label}
            </button>
          ))}
        </div>

        {/* Logs Display */}
        <div className="tactical-card max-h-96 overflow-y-auto">
          <div className="tactical-label mb-4">SYSTEM EVENTS</div>
          <div className="space-y-1 font-mono text-xs">
            {filteredLogs.length > 0 ? (
              filteredLogs.map((log) => (
                <div
                  key={log.id}
                  className={`p-2 border-l-2 border-green-400 pl-3 ${getLogColor(log.type)}`}
                >
                  <span className="opacity-60">[{log.time}]</span>
                  <span className="ml-2">{log.message}</span>
                </div>
              ))
            ) : (
              <div className="text-green-400 opacity-60 p-2">NO EVENTS LOGGED</div>
            )}
          </div>
        </div>

        {/* Statistics */}
        <div className="mt-8 grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="tactical-card">
            <div className="tactical-label">TOTAL EVENTS</div>
            <div className="text-green-400 text-2xl font-bold mt-2">{logs.length}</div>
          </div>
          <div className="tactical-card">
            <div className="tactical-label">NOMINAL</div>
            <div className="text-green-400 text-2xl font-bold mt-2">
              {logs.filter((l) => l.type === 'nominal').length}
            </div>
          </div>
          <div className="tactical-card">
            <div className="tactical-label">WARNINGS</div>
            <div className="text-yellow-400 text-2xl font-bold mt-2">
              {logs.filter((l) => l.type === 'warning').length}
            </div>
          </div>
          <div className="tactical-card">
            <div className="tactical-label">CRITICAL</div>
            <div className="text-red-400 text-2xl font-bold mt-2">
              {logs.filter((l) => l.type === 'critical').length}
            </div>
          </div>
        </div>

        {/* System Health Summary */}
        <div className="mt-8 tactical-card">
          <div className="tactical-label">SYSTEM HEALTH</div>
          <div className="mt-4 space-y-3">
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="tactical-label">STRUCTURAL INTEGRITY</span>
                <span className="text-green-400">100%</span>
              </div>
              <div className="w-full h-2 border border-green-400 bg-black">
                <div className="h-full bg-green-400" style={{ width: '100%' }}></div>
              </div>
            </div>
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="tactical-label">PROPULSION SYSTEM</span>
                <span className="text-green-400">100%</span>
              </div>
              <div className="w-full h-2 border border-green-400 bg-black">
                <div className="h-full bg-green-400" style={{ width: '100%' }}></div>
              </div>
            </div>
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="tactical-label">AVIONICS SYSTEM</span>
                <span className="text-green-400">100%</span>
              </div>
              <div className="w-full h-2 border border-green-400 bg-black">
                <div className="h-full bg-green-400" style={{ width: '100%' }}></div>
              </div>
            </div>
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="tactical-label">COMMUNICATION</span>
                <span className="text-green-400">100%</span>
              </div>
              <div className="w-full h-2 border border-green-400 bg-black">
                <div className="h-full bg-green-400" style={{ width: '100%' }}></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
