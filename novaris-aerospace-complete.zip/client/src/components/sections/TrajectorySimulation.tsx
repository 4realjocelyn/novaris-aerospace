import React, { useState, useEffect } from 'react';

/**
 * Trajectory Simulation Component
 * Design: Military-grade tactical dashboard with animated trajectory
 * Features: Animated flight path, mission phases, orbital mechanics visualization
 */
export default function TrajectorySimulation() {
  const [trajectoryPhase, setTrajectoryPhase] = useState(0);
  const [animationProgress, setAnimationProgress] = useState(0);

  const phases = [
    { name: 'LAUNCH', duration: 120, color: '#00ff00' },
    { name: 'ASCENT', duration: 240, color: '#00ccff' },
    { name: 'APOGEE', duration: 60, color: '#ffff00' },
    { name: 'DESCENT', duration: 180, color: '#ff6600' },
    { name: 'RECOVERY', duration: 120, color: '#00ff00' },
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setAnimationProgress((prev) => (prev + 1) % 100);
    }, 50);
    return () => clearInterval(interval);
  }, []);

  const handlePhaseChange = (index: number) => {
    setTrajectoryPhase(index);
  };

  return (
    <section
      id="trajectory"
      className="relative bg-black border-b-4 border-green-400 py-16 px-4 overflow-hidden"
    >
      {/* Tactical Grid Background */}
      <div className="absolute inset-0 tactical-grid opacity-10 pointer-events-none"></div>

      <div className="relative z-10 max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="mb-8">
          <div className="tactical-label">MISSION PROFILE</div>
          <h2 className="tactical-heading text-3xl md:text-4xl mt-2">TRAJECTORY SIMULATION</h2>
        </div>

        {/* Main Trajectory Visualization */}
        <div className="tactical-card mb-8">
          <div className="tactical-label">FLIGHT PATH VISUALIZATION</div>
          <div className="mt-6 relative h-80 bg-black border border-green-400 border-opacity-30">
            {/* SVG Trajectory Path */}
            <svg className="absolute inset-0 w-full h-full" viewBox="0 0 800 300">
              {/* Grid lines */}
              <defs>
                <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                  <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#00ff00" strokeWidth="0.5" opacity="0.1" />
                </pattern>
              </defs>
              <rect width="800" height="300" fill="url(#grid)" />

              {/* Trajectory curve */}
              <path
                d="M 50 250 Q 200 100, 400 50 T 750 250"
                stroke="#00ff00"
                strokeWidth="2"
                fill="none"
                opacity="0.5"
              />

              {/* Animated rocket position */}
              <circle
                cx={50 + (animationProgress / 100) * 700}
                cy={250 - Math.sin((animationProgress / 100) * Math.PI) * 200}
                r="8"
                fill="#00ff00"
                opacity="0.8"
              >
                <animate
                  attributeName="r"
                  values="8;12;8"
                  dur="1s"
                  repeatCount="indefinite"
                />
              </circle>

              {/* Launch site */}
              <rect x="40" y="240" width="20" height="20" fill="none" stroke="#00ff00" strokeWidth="2" />
              <text x="50" y="270" textAnchor="middle" fill="#00ff00" fontSize="12">
                LAUNCH
              </text>

              {/* Landing site */}
              <rect x="740" y="240" width="20" height="20" fill="none" stroke="#00ff00" strokeWidth="2" />
              <text x="750" y="270" textAnchor="middle" fill="#00ff00" fontSize="12">
                LANDING
              </text>

              {/* Apogee marker */}
              <circle cx="400" cy="50" r="6" fill="none" stroke="#ffff00" strokeWidth="2" />
              <text x="400" y="30" textAnchor="middle" fill="#ffff00" fontSize="12">
                APOGEE
              </text>
            </svg>

            {/* Altitude scale */}
            <div className="absolute left-0 top-0 bottom-0 w-12 border-r border-green-400 border-opacity-30 flex flex-col justify-between text-xs text-green-400 opacity-60 px-1">
              <div>300 KM</div>
              <div>150 KM</div>
              <div>0 KM</div>
            </div>

            {/* Distance scale */}
            <div className="absolute bottom-0 left-12 right-0 h-8 border-t border-green-400 border-opacity-30 flex justify-between text-xs text-green-400 opacity-60 px-4">
              <div>0 KM</div>
              <div>500 KM</div>
              <div>1000 KM</div>
            </div>
          </div>
        </div>

        {/* Mission Phases */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Phase Timeline */}
          <div className="tactical-card">
            <div className="tactical-label">MISSION PHASES</div>
            <div className="mt-4 space-y-3">
              {phases.map((phase, index) => (
                <button
                  key={index}
                  onClick={() => handlePhaseChange(index)}
                  className={`w-full p-3 text-left border-2 transition-all ${
                    trajectoryPhase === index
                      ? 'border-green-400 bg-green-400 bg-opacity-20'
                      : 'border-green-400 border-opacity-30 hover:border-opacity-60'
                  }`}
                >
                  <div className="flex justify-between items-center">
                    <div>
                      <div className="tactical-label text-xs">{phase.name}</div>
                      <div className="text-green-400 text-sm mt-1">{phase.duration}s</div>
                    </div>
                    <div className="w-3 h-3 rounded-full" style={{ backgroundColor: phase.color }}></div>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Current Phase Details */}
          <div className="tactical-card">
            <div className="tactical-label">CURRENT PHASE</div>
            <div className="mt-4 space-y-4">
              <div>
                <div className="tactical-label">PHASE NAME</div>
                <div className="text-green-400 text-lg font-bold mt-1">{phases[trajectoryPhase].name}</div>
              </div>
              <div>
                <div className="tactical-label">PHASE DURATION</div>
                <div className="text-green-400 text-lg font-bold mt-1">{phases[trajectoryPhase].duration}s</div>
              </div>
              <div>
                <div className="tactical-label">PROGRESS</div>
                <div className="mt-2 w-full h-4 border border-green-400 bg-black relative">
                  <div
                    className="h-full bg-green-400 transition-all"
                    style={{ width: `${animationProgress}%` }}
                  ></div>
                </div>
                <div className="text-green-400 text-xs mt-1">{animationProgress}%</div>
              </div>
            </div>
          </div>
        </div>

        {/* Orbital Mechanics Data */}
        <div className="mt-8 tactical-card">
          <div className="tactical-label">ORBITAL MECHANICS</div>
          <div className="mt-4 grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
            <div>
              <span className="tactical-label">APOGEE</span>
              <div className="text-green-400 font-bold">300 KM</div>
            </div>
            <div>
              <span className="tactical-label">PERIGEE</span>
              <div className="text-green-400 font-bold">0 KM</div>
            </div>
            <div>
              <span className="tactical-label">INCLINATION</span>
              <div className="text-green-400 font-bold">51.6°</div>
            </div>
            <div>
              <span className="tactical-label">ORBITAL PERIOD</span>
              <div className="text-green-400 font-bold">90 MIN</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
