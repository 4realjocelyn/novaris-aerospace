import React, { useState, useEffect } from 'react';
import { LineChart, Line, AreaChart, Area, ResponsiveContainer, XAxis, YAxis, CartesianGrid } from 'recharts';

/**
 * Telemetry Dashboard Component
 * Design: Professional data visualization with cinematic styling
 */
export default function TelemetryDashboard() {
  const [telemetryData, setTelemetryData] = useState<any[]>([]);
  const [radarRotation, setRadarRotation] = useState(0);

  useEffect(() => {
    const data = Array.from({ length: 20 }, (_, i) => ({
      time: `T+${i}:00`,
      altitude: Math.random() * 100 + 50,
      velocity: Math.random() * 200 + 100,
      temperature: Math.random() * 50 + 20,
    }));
    setTelemetryData(data);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setRadarRotation((prev) => (prev + 2) % 360);
    }, 50);
    return () => clearInterval(interval);
  }, []);

  return (
    <section id="telemetry" className="relative py-32 px-4 bg-gradient-to-b from-slate-950 to-slate-900">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="mb-20">
          <span className="text-blue-400 text-sm font-semibold uppercase tracking-widest">Live Data</span>
          <h2 className="cinematic-heading text-4xl md:text-5xl mt-4 mb-6">
            Mission
            <span className="block text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-cyan-400">
              Telemetry
            </span>
          </h2>
        </div>

        {/* Charts Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Altitude Chart */}
          <div className="cinematic-card">
            <h3 className="text-lg font-bold text-white mb-6">Altitude Profile</h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={telemetryData}>
                  <defs>
                    <linearGradient id="colorAltitude" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#2563eb" stopOpacity={0.8} />
                      <stop offset="95%" stopColor="#2563eb" stopOpacity={0.1} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.3} />
                  <XAxis dataKey="time" stroke="#94a3b8" style={{ fontSize: '12px' }} />
                  <YAxis stroke="#94a3b8" style={{ fontSize: '12px' }} />
                  <Area type="monotone" dataKey="altitude" stroke="#2563eb" fillOpacity={1} fill="url(#colorAltitude)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Velocity Chart */}
          <div className="cinematic-card">
            <h3 className="text-lg font-bold text-white mb-6">Velocity Profile</h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={telemetryData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.3} />
                  <XAxis dataKey="time" stroke="#94a3b8" style={{ fontSize: '12px' }} />
                  <YAxis stroke="#94a3b8" style={{ fontSize: '12px' }} />
                  <Line type="monotone" dataKey="velocity" stroke="#06b6d4" dot={false} strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Real-time Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {[
            { label: 'Altitude', value: '85.3 KM' },
            { label: 'Velocity', value: '285 M/S' },
            { label: 'Acceleration', value: '9.8 M/S²' },
            { label: 'Fuel', value: '87%' },
          ].map((stat, index) => (
            <div key={index} className={`cinematic-card text-center stagger-${index + 1} fade-in-up`}>
              <div className="stat-label mb-2">{stat.label}</div>
              <div className="stat-value">{stat.value}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
