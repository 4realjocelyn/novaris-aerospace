import React from 'react';

/**
 * Missions Section Component
 * Design: Cinematic showcase with feature cards and imagery
 */
export default function MissionsSection() {
  const missions = [
    {
      id: 1,
      title: 'NOVARIS-01',
      subtitle: 'Orbital Deployment',
      description: 'Advanced satellite deployment mission to low Earth orbit with precision guidance systems.',
      image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663666297408/W6GtBouUUUaTgbHUktqoJw/novaris-satellite-3AFeNSmtjnADkh3PJCrrRP.webp',
      specs: ['Altitude: 400 KM', 'Inclination: 51.6°', 'Payload: 500 KG'],
    },
    {
      id: 2,
      title: 'NOVARIS-02',
      subtitle: 'Lunar Transfer',
      description: 'Long-duration lunar transfer mission with advanced propulsion and navigation systems.',
      image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663666297408/W6GtBouUUUaTgbHUktqoJw/novaris-space-station-SnkDWJQYGH828uJBhqhKvR.webp',
      specs: ['Range: 384,400 KM', 'Duration: 72 Hours', 'Payload: 1000 KG'],
    },
    {
      id: 3,
      title: 'NOVARIS-03',
      subtitle: 'Deep Space Probe',
      description: 'Interplanetary exploration mission with autonomous systems and real-time telemetry.',
      image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663666297408/W6GtBouUUUaTgbHUktqoJw/novaris-rocket-launch-8DJGwUrGgMW32pAGfRfkcX.webp',
      specs: ['Target: Mars', 'Velocity: 11.2 KM/S', 'Payload: 2000 KG'],
    },
  ];

  return (
    <section id="missions" className="relative py-32 px-4 bg-gradient-to-b from-slate-900 to-slate-950">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="mb-20">
          <span className="text-blue-400 text-sm font-semibold uppercase tracking-widest">Our Missions</span>
          <h2 className="cinematic-heading text-4xl md:text-5xl mt-4 mb-6">
            Pioneering Space
            <span className="block text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-cyan-400">
              Exploration
            </span>
          </h2>
          <p className="text-slate-400 text-lg max-w-2xl">
            From orbital deployments to deep space exploration, NOVARIS missions push the boundaries of what's possible in aerospace technology.
          </p>
        </div>

        {/* Missions Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {missions.map((mission, index) => (
            <div
              key={mission.id}
              className={`feature-card group ${index === 0 ? 'stagger-1' : index === 1 ? 'stagger-2' : 'stagger-3'} fade-in-up`}
            >
              {/* Mission Image */}
              <div className="relative h-48 mb-6 overflow-hidden rounded-lg">
                <img
                  src={mission.image}
                  alt={mission.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900 to-transparent opacity-50" />
              </div>

              {/* Content */}
              <div className="space-y-4">
                <div>
                  <h3 className="text-xl font-bold text-white mb-1">{mission.title}</h3>
                  <p className="text-blue-400 font-semibold">{mission.subtitle}</p>
                </div>

                <p className="text-slate-300 text-sm leading-relaxed">
                  {mission.description}
                </p>

                {/* Specs */}
                <div className="space-y-2 pt-4 border-t border-slate-700">
                  {mission.specs.map((spec, idx) => (
                    <div key={idx} className="flex justify-between text-sm">
                      <span className="stat-label">{spec.split(':')[0]}</span>
                      <span className="text-slate-300">{spec.split(':')[1]}</span>
                    </div>
                  ))}
                </div>

                {/* CTA */}
                <button className="w-full mt-6 px-4 py-2 rounded-lg border border-blue-400 text-blue-400 text-sm font-semibold hover:bg-blue-400 hover:text-slate-900 transition-all duration-300">
                  View Mission
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
